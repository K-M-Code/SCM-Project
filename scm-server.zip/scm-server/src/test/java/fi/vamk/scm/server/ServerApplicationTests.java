package fi.vamk.scm.server;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerApplicationTests {


}